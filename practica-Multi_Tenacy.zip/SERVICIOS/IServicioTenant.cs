﻿namespace $safeprojectname$.Servicios
{
    public interface IServicioTenant
    {
        string ObtenerTenant();
    }
}
