﻿namespace $safeprojectname$.Servicios
{
    public class Constantes
    {
        public const string ClaimTenantId = "tenantId";
    }
}
