﻿namespace $safeprojectname$.Entidades
{
    public class Producto:IEntidadTenant
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string TenantID { get; set; } = null!;
    }
}
