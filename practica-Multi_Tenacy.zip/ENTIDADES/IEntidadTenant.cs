﻿namespace $safeprojectname$.Entidades
{
    public interface IEntidadTenant
    {
        string TenantID { get; set; }
    }
}
