﻿namespace $safeprojectname$.Entidades
{
    public class País: IEntidadComun

    {
        public int Id { get; internal set; }
        public string Nombre { get; set; } = null!;
    }
}
