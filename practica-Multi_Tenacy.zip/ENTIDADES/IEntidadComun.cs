﻿namespace $safeprojectname$.Entidades
{
    public interface IEntidadComun
    {
    }
}
