﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Entidades;
using $safeprojectname$.Servicios;
using System.Linq.Expressions;
using System.Reflection;

namespace $safeprojectname$.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        private string tenantId;   

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options,
            IServicioTenant servicioTenant)
            : base(options)
        {
            tenantId = servicioTenant.ObtenerTenant();
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            foreach(var item in ChangeTracker.Entries().Where(e => e.State == EntityState.Added
            && e.Entity is IEntidadTenant))
            {
                if (string.IsNullOrEmpty(tenantId))
                {
                    throw new Exception($"Tenant ID no encontrado"); 
                }
                var entidad = item.Entity as IEntidadTenant;
                entidad!.TenantID = tenantId;
            }
            return base.SaveChangesAsync(cancellationToken);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<País>().HasData(new País[]
            {
                new País{Id = 1, Nombre = "mexico"},
                new País{Id = 2, Nombre = "usa"},
                new País{Id = 3, Nombre = "peru"}
            });

            foreach(var entidad in builder.Model.GetEntityTypes())
            {
                var tipo = entidad.ClrType;

                if (typeof(IEntidadTenant).IsAssignableFrom(tipo))
                {
                    //Armar el Filtro

                    var metodo = typeof(ApplicationDbContext)
                        .GetMethod(nameof(ArmarFiltroGlobalTenant),
                        BindingFlags.NonPublic | BindingFlags.Static
                        )?.MakeGenericMethod(tipo);

                    var filtro = metodo?.Invoke(null, new object[]{ tenantId});
                    entidad.SetQueryFilter(queryFilter: filtro as LambdaExpression);
                    entidad.AddIndex(entidad.FindProperty(nameof(IEntidadTenant.TenantID))!);
                }
                else if (tipo.DebeSaltarValidacionTenant())
                {
                    continue;
                }
                else
                {
                    throw new Exception($"La entidad Tenant no ha sido marcada como tenant o comun");
                }
            }
        }
        private static LambdaExpression ArmarFiltroGlobalTenant<TEntidad>(ApplicationDbContext context)
            where TEntidad : class, IEntidadTenant
        {
            Expression<Func<TEntidad, bool>> filtro = x => x.TenantID == context.tenantId;
            return filtro;
        }
        public DbSet<Producto> Productos => Set<Producto>();
        public DbSet<País> Paises => Set<País>();

    }
}