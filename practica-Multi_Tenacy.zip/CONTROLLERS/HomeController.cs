﻿using Microsoft.AspNetCore.Mvc;
using $safeprojectname$.Entidades;
using $safeprojectname$.Models;
using System.Diagnostics;

namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationsDbContext context;

        public HomeController(ILogger<HomeController> logger,
            ApplicationsDbContext context)
        {
            _logger = logger;
            this.context = context;
        }

        public async Task<IActionResult> Index()
        {
            var modelo = await ConstruirModeloHomeIndex();
            return View(modelo);
        }

        public ApplicationsDbContext GetContext()
        {
            return context;
        }

        [HttpPost]
        public async Task<IActionResult> Index(Producto producto)
        {
            context.Add(producto);
            await context.SaveChangesAsync();
            var modelo = await ConstruirModeloHomeIndex();
            return View (modelo);
        }

        private async Task<HomeIndexViewModel> ConstruirModeloHomeIndex()
        {
            var productos = await context.Productos.ToListAsync();
            var paises = await context.Paises.ToLisAsync();

            var modelo = new HomeIndexViewModel();
            modelo.Productos = productos;
            modelo.Paises = paises;
            return modelo;
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}