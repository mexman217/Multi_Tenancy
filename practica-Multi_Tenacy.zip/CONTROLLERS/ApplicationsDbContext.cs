﻿namespace $safeprojectname$.Controllers
{
    public class ApplicationsDbContext
    {
        public object Productos { get; internal set; }
        public object Paises { get; internal set; }
    }
}