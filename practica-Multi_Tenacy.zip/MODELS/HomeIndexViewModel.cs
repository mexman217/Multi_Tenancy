﻿using $safeprojectname$.Entidades;

namespace $safeprojectname$.Models
{
    public class HomeIndexViewModel
    {
        public IEnumerable<Producto> Productos { get; set; } = new List<Producto>();
        public IEnumerable<País> Paises { get; set; } = new List<País>();
    }
}
